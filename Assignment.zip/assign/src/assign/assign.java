package assign;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class assign {

	private JFrame frame;
	private JTextField textField1;
	
	int input1;
	int input2;
	int output;
	private JTextField textField2;
	private JTextField textField3;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					assign window = new assign();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public assign() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 423, 215);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField1 = new JTextField();
		textField1.setBounds(96, 10, 65, 23);
		frame.getContentPane().add(textField1);
		textField1.setColumns(10);
		
		JButton btnSubtract = new JButton("-");
		btnSubtract.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input1=Integer.parseInt(textField1.getText());
				input2=Integer.parseInt(textField2.getText());
				output=input1-input2;
				textField3.setText(Integer.toString(output));
			}
		});
		btnSubtract.setBounds(307, 10, 89, 23);
		frame.getContentPane().add(btnSubtract);
		
		JButton btnPercentage = new JButton("%");
		btnPercentage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input1=Integer.parseInt(textField1.getText());
				input2=Integer.parseInt(textField2.getText());
				output=input1%input2;
				textField3.setText(Integer.toString(output));
			}
		});
		btnPercentage.setBounds(208, 10, 89, 23);
		frame.getContentPane().add(btnPercentage);
		
		JButton btnMultiply = new JButton("*");
		btnMultiply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input1=Integer.parseInt(textField1.getText());
				input2=Integer.parseInt(textField2.getText());
				output=input1*input2;
				textField3.setText(Integer.toString(output));
			}
		});
		btnMultiply.setBounds(307, 42, 89, 23);
		frame.getContentPane().add(btnMultiply);
		
		JButton btnAdd = new JButton("+");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input1=Integer.parseInt(textField1.getText());
				input2=Integer.parseInt(textField2.getText());
				output=input1+input2;
				textField3.setText(Integer.toString(output));
			}
		});
		btnAdd.setBounds(208, 42, 89, 23);
		frame.getContentPane().add(btnAdd);
		
		JButton btnDivide = new JButton("/");
		btnDivide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input1=Integer.parseInt(textField1.getText());
				input2=Integer.parseInt(textField2.getText());
				output=input1/input2;
				textField3.setText(Integer.toString(output));
			}
		});
		btnDivide.setBounds(258, 76, 89, 23);
		frame.getContentPane().add(btnDivide);
		
		textField2 = new JTextField();
		textField2.setBounds(96, 44, 65, 23);
		frame.getContentPane().add(textField2);
		textField2.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Input 1");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(40, 10, 46, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Input 2");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(40, 42, 46, 23);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField3 = new JTextField();
		textField3.setBounds(190, 110, 86, 20);
		frame.getContentPane().add(textField3);
		textField3.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Output");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(134, 113, 46, 14);
		frame.getContentPane().add(lblNewLabel_2);
	}
}
